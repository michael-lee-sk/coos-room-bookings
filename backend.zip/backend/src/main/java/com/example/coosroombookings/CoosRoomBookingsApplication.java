package com.example.coosroombookings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoosRoomBookingsApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoosRoomBookingsApplication.class, args);
    }
}